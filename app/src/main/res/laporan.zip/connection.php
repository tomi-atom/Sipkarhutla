<?php
// mengkoneksikan ke database
$server = "localhost";
$server_username = "sipkarhu_tla";
$server_password = "sipkarhutla";
$database_name = "sipkarhu_tla";
$conn = new Mysqli($server, $server_username, $server_password, $database_name);
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}