<?php

	if($_SERVER['REQUEST_METHOD']=='POST'){
        require 'connection.php';
        
     
        $tanggal = date("Y-m-d H:i:s");
        $nama = $_POST['nama'];
        $no_hp = $_POST['no_hp'];
        $ket = $_POST['ket'];
        $foto = $_POST['foto'];
        $lat = $_POST['lat'];
        $lng = $_POST['lng'];
      
        $path = "$tanggal.jpg";
      
	
		
		$letakFoto = "laporan/$tanggal.jpg";
	
        $response = array();
        $sql = "INSERT INTO laporan (tanggal,nama,hp,keterangan,foto,lat,lng)
        VALUES ('$tanggal','$nama','$no_hp','$ket','$path','$lat','$lng')";
        
        $result = mysqli_query($conn,$sql);
      	
	  
        if($result && file_put_contents($letakFoto,base64_decode($foto))){
       
          $code = 'berhasil';
          $message =  mysqli_error($conn);
          array_push($response,array("code"=>$code,"message"=>$message));
          echo json_encode($response);
           
        }else{
            
           $code = 'login_failed';
          $message =  mysqli_error($conn);
          array_push($response,array("code"=>$code,"message"=>$message));
          echo json_encode($response);
          
        }
        mysqli_close($conn);
	}else{
		echo "Error";
	}

?>
