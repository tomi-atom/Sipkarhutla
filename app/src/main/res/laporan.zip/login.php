<?php
require 'connection.php';

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT * from users WHERE  username ='".$username."' &&  password ='".$password."' ";

$result = mysqli_query($conn,$sql);
$response = array();

if (mysqli_num_rows($result)>0) {
  $row = mysqli_fetch_array($result);
   $id = $row['id'];
    $nama = $row['nama'];
   $message = "berhasil.. ";
  $code = "login_success";
  array_push($response,array("code"=>$code,"id"=>$id,"nama"=>$nama,"message"=>$message));
  echo json_encode($response);
}else {
  $code = "login_failed";
  //$message = "Data tidak ditemukan, Tolong di coba lagi.... ";
   $message =  mysqli_error($conn);
  array_push($response,array("code"=>$code,"message"=>$message));
  echo json_encode($response);

}
mysqli_close($con);
?>
