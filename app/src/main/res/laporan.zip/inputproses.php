<?php

	if($_SERVER['REQUEST_METHOD']=='POST'){
        require 'connection.php';
        
     
        $id = $_POST['id'];
        $updateby = $_POST['updateby'];
    
	
        $response = array();
          $sql = "UPDATE laporan SET status = '1', updateby = '$updateby'  WHERE id = $id";
          
        $result = mysqli_query($conn,$sql);
      	
	  
        if($result){
       
          $code = 'berhasil';
          $message =  mysqli_error($conn);
          array_push($response,array("code"=>$code,"message"=>$message));
          echo json_encode($response);
           
        }else{
            
           $code = 'login_failed';
          $message =  mysqli_error($conn);
          array_push($response,array("code"=>$code,"message"=>$message));
          echo json_encode($response);
          
        }
        mysqli_close($conn);
	}else{
		echo "Error";
	}

?>
